﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmTransactionBorrow : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;

        public frmTransactionBorrow()
        {
            InitializeComponent();
        }

        private void frmTransactionBorrow_Load(object sender, EventArgs e)
        {
            string date = DateTime.Now.ToString("MMMM dd, yyyy");
            txtDate.Text = date;


            //FOR THE DATA GRID OF BORROWERS
            con.Open();

            gridBorrowers.ColumnCount = 3;

            gridBorrowers.Columns[0].Name = "ID Number";
            gridBorrowers.Columns[1].Name = "First Name";
            gridBorrowers.Columns[2].Name = "Last Name";

            cmd = new SqlCommand("SELECT * FROM BORROWERS", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vidnum;
            string vfirstname;
            string vlastname;


            while (reader.Read())
            {
                vidnum = reader["id_num"].ToString();
                vfirstname = reader["first_name"].ToString();
                vlastname = reader["last_name"].ToString();


                string[] row = new string[] { vidnum, vfirstname, vlastname };
                gridBorrowers.Rows.Add(row);
            }


            con.Close();



            //FOR DATA GRID OF BOOKS

            con.Open();


            gridBooks.ColumnCount = 4;

            gridBooks.Columns[0].Name = "Accession Number";
            gridBooks.Columns[1].Name = "Title";
            gridBooks.Columns[2].Name = "Author";
            gridBooks.Columns[3].Name = "Status";

            cmd = new SqlCommand("SELECT * FROM BOOKS WHERE status = '" + "AVAILABLE" + "'", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vaccessnum;
            string vtitle;
            string vauthor;
            string vstatus;


            while (reader.Read())
            {

                vaccessnum = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();


                string[] row = new string[] { vaccessnum, vtitle, vauthor, vstatus };
                gridBooks.Rows.Add(row);
            }

            con.Close();


        }

       

        private void lblTransactionNo_Click(object sender, EventArgs e)
        {

        }

        private void lblBorrowerID_Click(object sender, EventArgs e)
        {

        }

        private void lblFirst_Click(object sender, EventArgs e)
        {

        }

        private void lblLast_Click(object sender, EventArgs e)
        {

        }

        private void lblAccNum_Click(object sender, EventArgs e)
        {

        }

        private void lblTitleHolder_Click(object sender, EventArgs e)
        {

        }

        private void lblAuthorHolder_Click(object sender, EventArgs e)
        {

        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            
        }

        private void txtTransactionNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void gridBorrowers_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            con.Open();
            if (e.RowIndex >= 0)
            {
                txtBorrowerID.Text = "";
                txtFirstName.Text = "";
                txtLastName.Text = "";

                DataGridViewRow row = this.gridBorrowers.Rows[e.RowIndex];
                txtBorrowerID.Text = row.Cells["ID Number"].Value.ToString();
                txtFirstName.Text = row.Cells["First Name"].Value.ToString();
                txtLastName.Text = row.Cells["Last Name"].Value.ToString();
            }
            con.Close();
        }

        private void gridBooks_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            con.Open();
            if (e.RowIndex >= 0)
            {
                txtAccNo.Text = "";
                txtTitle.Text = "";
                txtAuthor.Text = "";


                DataGridViewRow row = this.gridBooks.Rows[e.RowIndex];
                txtAccNo.Text = row.Cells["Accession Number"].Value.ToString();
                txtTitle.Text = row.Cells["Title"].Value.ToString();
                txtAuthor.Text = row.Cells["Author"].Value.ToString();
            }
            con.Close();
        }

        private void txtSearchBook_KeyDown(object sender, KeyEventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("SELECT * FROM BOOKS WHERE status = '" + "AVAILABLE" + "' AND accession_num LIKE '%" + txtSearchBook.Text + "%' OR title LIKE '%" + txtSearchBook.Text + "%' OR author LIKE '" + txtSearchBook.Text + "%' OR status LIKE '" + txtSearchBook.Text +"'", con);
        
            cmd.ExecuteNonQuery();

            SqlDataReader reader = cmd.ExecuteReader();

            string vaccession_num;
            string vtitle;
            string vauthor;
            string vstatus;



            gridBooks.Rows.Clear();
            
            while (reader.Read())
            {
                vaccession_num = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();

                if(vstatus == "AVAILABLE")
                {
                    string[] row = new string[] { vaccession_num, vtitle, vauthor, vstatus };
                    gridBooks.Rows.Add(row);
                }

                else
                {
                    
                }

                
            }

            con.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();


            string date = DateTime.Now.ToString("yyyy-MM-dd");
            cmd = new SqlCommand("INSERT INTO BORROW(TransactionID, accession_number, borrower_ID, date_borrowed)VALUES('" + txtTransactionNo.Text + "','" + txtAccNo.Text + "','" + txtBorrowerID.Text + "','" + date + "')", con);
            cmd.ExecuteNonQuery();

            //CHANGING THE STATUS OF THE BOOK
            string borrowed = "BORROWED";
            cmd = new SqlCommand("UPDATE BOOKS SET status = '" + borrowed + "' WHERE accession_num = '" + txtAccNo.Text + "'", con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("BORROWED SUCCESSFULLY!");


            //CLEAR ALL TEXTBOXES AND LABELS
            txtTransactionNo.Text = "";
            txtBorrowerID.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtAccNo.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";

            con.Close();




            //REFRESH/UPDATE DATA GRID VIEW
            con.Open();


            gridBooks.Rows.Clear();

            gridBooks.ColumnCount = 4;

            gridBooks.Columns[0].Name = "Accession Number";
            gridBooks.Columns[1].Name = "Title";
            gridBooks.Columns[2].Name = "Author";
            gridBooks.Columns[3].Name = "Status";

            cmd = new SqlCommand("SELECT * FROM BOOKS WHERE status = '" + "AVAILABLE" + "'", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vaccessnum;
            string vtitle;
            string vauthor;
            string vstatus;


            while (reader.Read())
            {

                vaccessnum = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();


                string[] row = new string[] { vaccessnum, vtitle, vauthor, vstatus };
                gridBooks.Rows.Add(row);
            }

            con.Close();
        }

        private void txtSearchBorrower_KeyDown(object sender, KeyEventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("SELECT * FROM BORROWERS WHERE id_num LIKE '%" + txtSearchBorrower.Text + "%' OR first_name LIKE '%" + txtSearchBorrower.Text + "%' OR last_name LIKE '" + txtSearchBorrower.Text + "'", con);
            cmd.ExecuteNonQuery();

            SqlDataReader reader = cmd.ExecuteReader();

            string vidnum;
            string vfirstname;
            string vlast_name;

            gridBorrowers.Rows.Clear();

            while (reader.Read())
            {
                vidnum = reader["id_num"].ToString();
                vfirstname = reader["first_name"].ToString();
                vlast_name = reader["last_name"].ToString();

                string[] row = new string[] { vidnum, vfirstname, vlast_name };
                gridBorrowers.Rows.Add(row);
            }

            con.Close();
        }
    }
}
