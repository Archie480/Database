﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmBooks : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;

        public frmBooks()
        {
            InitializeComponent();
        }

        private void frmBooks_Load(object sender, EventArgs e)
        {
            con.Open();


            gridBooks.ColumnCount = 4;

            gridBooks.Columns[0].Name = "Accession Number";
            gridBooks.Columns[1].Name = "Title";
            gridBooks.Columns[2].Name = "Author";
            gridBooks.Columns[3].Name = "Status";

            cmd = new SqlCommand("SELECT * FROM BOOKS", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vaccessnum;
            string vtitle;
            string vauthor;
            string vstatus;


            while (reader.Read())
            {

                vaccessnum = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();


                string[] row = new string[] { vaccessnum, vtitle, vauthor, vstatus };
                gridBooks.Rows.Add(row);
            }

            con.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("INSERT INTO BOOKS(accession_num,title,author, status)VALUES('" + txtNo.Text + "','" + txtTitle.Text + "','" + txtAuthor.Text + "','" + "AVAILABLE" + "')", con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("SUCCESSFULLY ADDED!");

            string vaccessnum;
            string vtitle;
            string vauthor;
            string vstatus;

            vaccessnum = txtNo.Text;
            vtitle = txtTitle.Text;
            vauthor = txtAuthor.Text;
            vstatus = txtStatus.Text;

            string[] row = new string[] { vaccessnum, vtitle, vauthor, vstatus };
            gridBooks.Rows.Add(row);

            txtNo.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtStatus.Text = "";


            con.Close();
        }

        private void grid1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            con.Open();
            if (e.RowIndex >= 0)
            {
                txtNo.Text = "";
                txtTitle.Text = "";
                txtAuthor.Text = "";
                txtStatus.Text = "";


                DataGridViewRow row = this.gridBooks.Rows[e.RowIndex];
                txtNo.Text = row.Cells["Accession Number"].Value.ToString();
                txtTitle.Text = row.Cells["Title"].Value.ToString();
                txtAuthor.Text = row.Cells["Author"].Value.ToString();
                txtStatus.Text = row.Cells["Status"].Value.ToString();
            }
            con.Close();
        }

        private void gridBooks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("UPDATE BOOKS SET accession_num = '" + txtNo.Text + "', title = '" + txtTitle.Text + "', author = '" + txtAuthor.Text + "', status = '" + txtStatus.Text + "' WHERE accession_num = '" + txtNo.Text + "'", con);
            cmd.ExecuteNonQuery();

            //REFRESH THE DATA GRID VIEW
            SqlCommand select = new SqlCommand("SELECT * FROM BOOKS", con);
            select.ExecuteNonQuery();

            SqlDataReader reader = select.ExecuteReader();
            
            string vaccession_num;
            string vtitle;
            string vauthor;
            string vstatus;

            gridBooks.Rows.Clear();

            while(reader.Read())
            {
                vaccession_num = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();

                string[] row = new string[] { vaccession_num, vtitle, vauthor, vstatus };
                gridBooks.Rows.Add(row);
            }

            txtNo.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtStatus.Text = "";

            MessageBox.Show("A BOOK WAS SUCCESSFULLY UPDATED!");

            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();

   
            DialogResult result = MessageBox.Show("Are you sure you want to delete this book?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            if (result == DialogResult.Yes)
            {
                // User clicked Yes
                cmd = new SqlCommand("DELETE FROM BOOKS WHERE accession_num = '" + txtNo.Text + "'", con);
                cmd.ExecuteNonQuery();

                SqlCommand select = new SqlCommand("SELECT * FROM BOOKS", con);
                select.ExecuteNonQuery();

                SqlDataReader reader = select.ExecuteReader();

                string vaccession_num;
                string vtitle;
                string vauthor;
                string vstatus;

                gridBooks.Rows.Clear();

                while (reader.Read())
                {
                    vaccession_num = reader["accession_num"].ToString();
                    vtitle = reader["title"].ToString();
                    vauthor = reader["author"].ToString();
                    vstatus = reader["status"].ToString();

                    string[] row = new string[] { vaccession_num, vtitle, vauthor, vstatus };
                    gridBooks.Rows.Add(row);
                }

                txtNo.Text = "";
                txtTitle.Text = "";
                txtAuthor.Text = "";
                txtStatus.Text = "";

            }
            else if (result == DialogResult.No)
            {
                // User clicked No
            }


            

            con.Close();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("SELECT * FROM BOOKS WHERE accession_num LIKE '%" + txtSearch.Text + "%' OR title LIKE '%" + txtSearch.Text + "%' OR author LIKE '" + txtSearch.Text + "%' OR status LIKE '" + txtStatus.Text + "'", con);
            cmd.ExecuteNonQuery();

            SqlDataReader reader = cmd.ExecuteReader();

            string vaccession_num;
            string vtitle;
            string vauthor;
            string vstatus;

            gridBooks.Rows.Clear();

            while (reader.Read())
            {
                vaccession_num = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();
                vstatus = reader["status"].ToString();

                string[] row = new string[] { vaccession_num, vtitle, vauthor, vstatus };
                gridBooks.Rows.Add(row);
            }

            con.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNo.Text = "";
            txtAuthor.Text = "";
            txtTitle.Text = "";
            txtStatus.Text = "";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
