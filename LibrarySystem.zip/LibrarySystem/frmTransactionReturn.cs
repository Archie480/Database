﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmTransactionReturn : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;
        public frmTransactionReturn()
        {
            InitializeComponent();
        }

        private void frmTransactionReturn_Load(object sender, EventArgs e)
        {
            con.Open();

            gridTransactions.ColumnCount = 4;

            gridTransactions.Columns[0].Name = "Transaction No.";
            gridTransactions.Columns[1].Name = "Book Acc. No.";
            gridTransactions.Columns[2].Name = "Borrower ID";
            gridTransactions.Columns[3].Name = "Date Borrowed";

            cmd = new SqlCommand("SELECT * FROM BORROW WHERE date_returned IS NULL", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vtransactionno;
            string vaccno;
            string vborrowerid;
            string vdate;


            while (reader.Read())
            {
                vtransactionno = reader["TransactionID"].ToString();
                vaccno = reader["accession_number"].ToString();
                vborrowerid = reader["borrower_ID"].ToString();
                vdate = reader["date_borrowed"].ToString();

                vdate = vdate.Substring(0,11);

                string[] row = new string[] { vtransactionno, vaccno, vborrowerid, vdate };
                gridTransactions.Rows.Add(row);
            }


            con.Close();
        }

        private void gridTransactions_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            con.Open();
            if (e.RowIndex >= 0)
            {
               
                DataGridViewRow row = this.gridTransactions.Rows[e.RowIndex];
                txtTransactionNo.Text = row.Cells["Transaction No."].Value.ToString();
                txtBorrowedDate.Text = row.Cells["Date Borrowed"].Value.ToString();
                txtBorrowerID.Text = row.Cells["Borrower ID"].Value.ToString();
                txtAccNo.Text = row.Cells["Book Acc. No."].Value.ToString();


                string vborrowerId = txtBorrowerID.Text;

                cmd = new SqlCommand("SELECT * FROM BORROWERS WHERE id_num = '" + vborrowerId + "'", con);
                cmd.ExecuteNonQuery();

                reader = cmd.ExecuteReader();

                string vid_num;
                string vfirst_name;
                string vlast_name;

                reader.Read();


                vid_num = reader["id_num"].ToString();
                vfirst_name = reader["first_name"].ToString();
                vlast_name = reader["last_name"].ToString();

                txtFirstName.Text = vfirst_name;
                txtLastName.Text = vlast_name;

                con.Close();


                con.Open();
                string vaccno = txtAccNo.Text;

                cmd = new SqlCommand("SELECT * FROM BOOKS WHERE accession_num = '" + vaccno + "'", con);
                cmd.ExecuteNonQuery();

                reader = cmd.ExecuteReader();

                string vaccnum;
                string vtitle;
                string vauthor;

                reader.Read();


                vaccnum = reader["accession_num"].ToString();
                vtitle = reader["title"].ToString();
                vauthor = reader["author"].ToString();

                txtTitle.Text = vtitle;
                txtAuthor.Text = vauthor;
            }

            con.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           

            con.Open();

            //CHANGING THE STATUS OF THE BOOK
            string available = "AVAILABLE";
            cmd = new SqlCommand("UPDATE BOOKS SET status = '" + available + "' WHERE accession_num = '" + txtAccNo.Text + "'", con);
            cmd.ExecuteNonQuery();

            con.Close();


            //FILLING THE DATE RETURNED
            con.Open();
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            cmd = new SqlCommand("UPDATE BORROW SET date_returned = '" + date + "' WHERE TransactionID = '" + txtTransactionNo.Text + "'", con);
            cmd.ExecuteNonQuery();


            con.Close();

            MessageBox.Show("BOOK RETURNED SUCCESSFULLY!");


            //CLEAR ALL TEXTBOXES

            txtTransactionNo.Text = "";
            txtBorrowedDate.Text = "";
            txtBorrowerID.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtAccNo.Text = "";
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtSearch.Text = "";

            //REFRESH THE DATA GRID VIEW

            gridTransactions.Rows.Clear();

            con.Open();

            gridTransactions.ColumnCount = 4;

            gridTransactions.Columns[0].Name = "Transaction No.";
            gridTransactions.Columns[1].Name = "Book Acc. No.";
            gridTransactions.Columns[2].Name = "Borrower ID";
            gridTransactions.Columns[3].Name = "Date Borrowed";

            cmd = new SqlCommand("SELECT * FROM BORROW WHERE date_returned IS NULL", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vtransactionno;
            string vaccno;
            string vborrowerid;
            string vdate;


            while (reader.Read())
            {
                vtransactionno = reader["TransactionID"].ToString();
                vaccno = reader["accession_number"].ToString();
                vborrowerid = reader["borrower_ID"].ToString();
                vdate = reader["date_borrowed"].ToString();

                vdate = vdate.Substring(0, 11);

                string[] row = new string[] { vtransactionno, vaccno, vborrowerid, vdate };
                gridTransactions.Rows.Add(row);
            }


            con.Close();



        }
    }
}
