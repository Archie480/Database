﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmBorrowers : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;

        public frmBorrowers()
        {
            InitializeComponent();
        }

        private void frmBorrowers_Load(object sender, EventArgs e)
        {
            con.Open();


            gridBorrowers.ColumnCount = 3;

            gridBorrowers.Columns[0].Name = "ID Number";
            gridBorrowers.Columns[1].Name = "First Name";
            gridBorrowers.Columns[2].Name = "Last Name";

            cmd = new SqlCommand("SELECT * FROM BORROWERS", con);

            cmd.ExecuteNonQuery();

            reader = cmd.ExecuteReader();

            string vidnum;
            string vfirstname;
            string vlastname;


            while (reader.Read())
            {
                vidnum = reader["id_num"].ToString();
                vfirstname = reader["first_name"].ToString();
                vlastname = reader["last_name"].ToString();


                string[] row = new string[] { vidnum, vfirstname, vlastname };
                gridBorrowers.Rows.Add(row);
            }

            con.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();

            cmd = new SqlCommand("INSERT INTO BORROWERS(id_num,first_name,last_name)VALUES('" + txtIDnum.Text + "','" + txtFirstName.Text + "','" + txtLastName.Text + "')", con);
            cmd.ExecuteNonQuery();

            MessageBox.Show("SUCCESSFULLY ADDED!");

            string vidnum;
            string vfirstname;
            string vlastname;

            vidnum = txtIDnum.Text;
            vfirstname = txtFirstName.Text;
            vlastname = txtLastName.Text;

            string[] row = new string[] { vidnum, vfirstname, vlastname };
            gridBorrowers.Rows.Add(row);

            txtIDnum.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";


            con.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("UPDATE BORROWERS SET id_num = '" + txtIDnum.Text + "', first_name = '" + txtFirstName.Text + "', last_name = '" + txtLastName.Text + "' WHERE id_num = '" + txtIDnum.Text + "'", con);
            cmd.ExecuteNonQuery();

            //REFRESH THE DATA GRID VIEW
            SqlCommand select = new SqlCommand("SELECT * FROM BORROWERS", con);
            select.ExecuteNonQuery();

            SqlDataReader reader = select.ExecuteReader();

            string vidnum;
            string vfirstname;
            string vlastname;

            gridBorrowers.Rows.Clear();

            while (reader.Read())
            {
                vidnum = reader["id_num"].ToString();
                vfirstname = reader["first_name"].ToString();
                vlastname = reader["last_name"].ToString();

                string[] row = new string[] { vidnum, vfirstname, vlastname };
                gridBorrowers.Rows.Add(row);
            }

            txtIDnum.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";

            MessageBox.Show("A BORROWER WAS SUCCESSFULLY UPDATED!");

            con.Close();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            con.Open();


            cmd = new SqlCommand("SELECT * FROM BORROWERS WHERE id_num LIKE '%" + txtSearch.Text + "%' OR first_name LIKE '%" + txtSearch.Text + "%' OR last_name LIKE '" + txtSearch.Text + "'", con);
            cmd.ExecuteNonQuery();

            SqlDataReader reader = cmd.ExecuteReader();

            string vidnum;
            string vfirstname;
            string vlast_name;

            gridBorrowers.Rows.Clear();

            while (reader.Read())
            {
                vidnum = reader["id_num"].ToString();
                vfirstname = reader["first_name"].ToString();
                vlast_name = reader["last_name"].ToString();

                string[] row = new string[] { vidnum, vfirstname, vlast_name };
                gridBorrowers.Rows.Add(row);
            }

            con.Close();
        }

        private void gridBorrowers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gridBorrowers_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            con.Open();
            if (e.RowIndex >= 0)
            {
                txtIDnum.Text = "";
                txtFirstName.Text = "";
                txtLastName.Text = "";

                DataGridViewRow row = this.gridBorrowers.Rows[e.RowIndex];
                txtIDnum.Text = row.Cells["ID Number"].Value.ToString();
                txtFirstName.Text = row.Cells["First Name"].Value.ToString();
                txtLastName.Text = row.Cells["Last Name"].Value.ToString();
            }
            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();


            DialogResult result = MessageBox.Show("Are you sure you want to delete this borrower?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            if (result == DialogResult.Yes)
            {
                // User clicked Yes
                cmd = new SqlCommand("DELETE FROM BORROWERS WHERE id_num = '" + txtIDnum.Text + "'", con);
                cmd.ExecuteNonQuery();

                SqlCommand select = new SqlCommand("SELECT * FROM BORROWERS", con);
                select.ExecuteNonQuery();

                SqlDataReader reader = select.ExecuteReader();

                string vidnum;
                string vfirstname;
                string vlastname;

                gridBorrowers.Rows.Clear();

                while (reader.Read())
                {
                    vidnum = reader["id_num"].ToString();
                    vfirstname = reader["first_name"].ToString();
                    vlastname = reader["last_name"].ToString();

                    string[] row = new string[] { vidnum, vfirstname, vlastname };
                    gridBorrowers.Rows.Add(row);
                }

                txtIDnum.Text = "";
                txtFirstName.Text = "";
                txtLastName.Text = "";


            }
            else if (result == DialogResult.No)
            {
                // User clicked No
            }

            

            con.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtIDnum.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
        }

        private void txtLastName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
