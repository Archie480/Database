﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmSignup : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;



        public frmSignup()
        {
            InitializeComponent();
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            new frmLogin().Show();
            this.Hide();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            //CHECKS IF SOME TEXTBOX ARE BLANKS
            if (txtUsername.Text == "" || txtPassword.Text == "" || txtConfirmPassword.Text == "")
            {
                MessageBox.Show("SOME INPUT FIELDS CANNOT BE BLANK!");
            }
            else
            {
                //IF THE TWO PASSWORDS ARE MATCHED
                if (txtPassword.Text.Equals(txtConfirmPassword.Text))
                {
                    //IF PASSWORD HAS NUMBER AND SPECIAL CHARACTER
                    if (CheckPasswordSpecialChar(txtPassword.Text) && CheckPasswordNumbers(txtPassword.Text))
                    {
                        //IF USERNAME IS ALREADY TAKEN
                        if (UserIdChecker(txtUsername.Text))
                        {
                            MessageBox.Show("USERNAME ALREADY EXIST");
                            txtUsername.Text = "";
                            txtPassword.Text = "";
                            txtConfirmPassword.Text = "";

                            txtUsername.Focus();
                            this.Refresh();
                        }
                        else
                        {
                            con.Open();


                            //ENCRYPTION OF PASSWORD
                            string vpass = txtPassword.Text;
                            string encryptedpass = EncryptPassword(vpass);

                            cmd = new SqlCommand("INSERT INTO Accounts(Username,Password)VALUES('" + txtUsername.Text + "','" + encryptedpass + "')", con);
                            cmd.ExecuteNonQuery();

                            MessageBox.Show("SUCCESSFULLY CREATED AN ACCOUNT!!");

                            new frmAdminDashboard().Show();
                            this.Hide();
                            con.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("PASSWORD MUST CONTAIN SPECIAL CHARACTER AND/OR NUMBER");
                    }

                }
                else
                {
                    MessageBox.Show("PASSWORDS DOESN'T MATCH");
                    txtPassword.Text = "";
                    txtConfirmPassword.Text = "";
                }
            }
        }


        private bool CheckPasswordNumbers(string Password)
        {
            string specialChar = "1234567890";
            foreach (var item in specialChar)
            {
                if (Password.Contains(item)) return true;
            }

            return false;
        }

        private bool CheckPasswordSpecialChar(string Password)
        {
            string specialChar = @"\|!#$%&/(*)=?@{},-;'<>_.";
            foreach (var item in specialChar)
            {
                if (Password.Contains(item)) return true;
            }

            return false;
        }

        private bool UserIdChecker(string Username)
        {
            con.Open();
            cmd = new SqlCommand("SELECT Username from Accounts where Username LIKE'" + Username + "';", con);
            cmd.ExecuteNonQuery();
            reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                con.Close();
                return true;
            }
            else
            {
                con.Close();
                return false;
            }
        }


        public string EncryptPassword(string password)
        {
            string Key = "ArchieBontogXXXX";

            byte[] iv = new byte[16];
            byte[] array;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(Key);
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(password);
                        }

                        array = memoryStream.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(array);
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            txtConfirmPassword.PasswordChar = '*';
        }

        private void frmSignup_Load(object sender, EventArgs e)
        {

        }
    }
}
