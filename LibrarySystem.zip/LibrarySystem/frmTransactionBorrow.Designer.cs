﻿namespace LibrarySystem
{
    partial class frmTransactionBorrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirst = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblBorrowerID = new System.Windows.Forms.Label();
            this.lblTransactionNo = new System.Windows.Forms.Label();
            this.lblLast = new System.Windows.Forms.Label();
            this.lblAccNum = new System.Windows.Forms.Label();
            this.lblTitleHolder = new System.Windows.Forms.Label();
            this.lblAuthorHolder = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnBorrow = new System.Windows.Forms.Button();
            this.txtTransactionNo = new System.Windows.Forms.TextBox();
            this.txtBorrowerID = new System.Windows.Forms.TextBox();
            this.txtAccNo = new System.Windows.Forms.TextBox();
            this.gridBorrowers = new System.Windows.Forms.DataGridView();
            this.txtSearchBorrower = new System.Windows.Forms.TextBox();
            this.lblSearchStudent = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.gridBooks = new System.Windows.Forms.DataGridView();
            this.lblSearchBook = new System.Windows.Forms.Label();
            this.txtSearchBook = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gridBorrowers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridBooks)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblFirst.Location = new System.Drawing.Point(16, 197);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(147, 29);
            this.lblFirst.TabIndex = 48;
            this.lblFirst.Text = "FIRST NAME";
            this.lblFirst.Click += new System.EventHandler(this.lblFirst_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(579, 92);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(68, 29);
            this.lblDate.TabIndex = 47;
            this.lblDate.Text = "DATE";
            // 
            // lblBorrowerID
            // 
            this.lblBorrowerID.AutoSize = true;
            this.lblBorrowerID.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblBorrowerID.Location = new System.Drawing.Point(16, 155);
            this.lblBorrowerID.Name = "lblBorrowerID";
            this.lblBorrowerID.Size = new System.Drawing.Size(164, 29);
            this.lblBorrowerID.TabIndex = 46;
            this.lblBorrowerID.Text = "BORROWER ID";
            this.lblBorrowerID.Click += new System.EventHandler(this.lblBorrowerID_Click);
            // 
            // lblTransactionNo
            // 
            this.lblTransactionNo.AutoSize = true;
            this.lblTransactionNo.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblTransactionNo.Location = new System.Drawing.Point(16, 96);
            this.lblTransactionNo.Name = "lblTransactionNo";
            this.lblTransactionNo.Size = new System.Drawing.Size(219, 29);
            this.lblTransactionNo.TabIndex = 45;
            this.lblTransactionNo.Text = "TRANSACTION NO.";
            this.lblTransactionNo.Click += new System.EventHandler(this.lblTransactionNo_Click);
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblLast.Location = new System.Drawing.Point(16, 242);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(137, 29);
            this.lblLast.TabIndex = 50;
            this.lblLast.Text = "LAST NAME";
            this.lblLast.Click += new System.EventHandler(this.lblLast_Click);
            // 
            // lblAccNum
            // 
            this.lblAccNum.AutoSize = true;
            this.lblAccNum.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblAccNum.Location = new System.Drawing.Point(572, 155);
            this.lblAccNum.Name = "lblAccNum";
            this.lblAccNum.Size = new System.Drawing.Size(120, 29);
            this.lblAccNum.TabIndex = 51;
            this.lblAccNum.Text = "BOOK NO.";
            this.lblAccNum.Click += new System.EventHandler(this.lblAccNum_Click);
            // 
            // lblTitleHolder
            // 
            this.lblTitleHolder.AutoSize = true;
            this.lblTitleHolder.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitleHolder.Location = new System.Drawing.Point(572, 197);
            this.lblTitleHolder.Name = "lblTitleHolder";
            this.lblTitleHolder.Size = new System.Drawing.Size(75, 29);
            this.lblTitleHolder.TabIndex = 52;
            this.lblTitleHolder.Text = "TITLE";
            this.lblTitleHolder.Click += new System.EventHandler(this.lblTitleHolder_Click);
            // 
            // lblAuthorHolder
            // 
            this.lblAuthorHolder.AutoSize = true;
            this.lblAuthorHolder.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblAuthorHolder.Location = new System.Drawing.Point(572, 238);
            this.lblAuthorHolder.Name = "lblAuthorHolder";
            this.lblAuthorHolder.Size = new System.Drawing.Size(101, 29);
            this.lblAuthorHolder.TabIndex = 53;
            this.lblAuthorHolder.Text = "AUTHOR";
            this.lblAuthorHolder.Click += new System.EventHandler(this.lblAuthorHolder_Click);
            // 
            // txtDate
            // 
            this.txtDate.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.txtDate.Location = new System.Drawing.Point(662, 89);
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(189, 35);
            this.txtDate.TabIndex = 56;
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.lblAuthor.Location = new System.Drawing.Point(163, 652);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(0, 28);
            this.lblAuthor.TabIndex = 62;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.lblTitle.Location = new System.Drawing.Point(692, 206);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(0, 28);
            this.lblTitle.TabIndex = 61;
            // 
            // btnBorrow
            // 
            this.btnBorrow.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.btnBorrow.Location = new System.Drawing.Point(596, 875);
            this.btnBorrow.Name = "btnBorrow";
            this.btnBorrow.Size = new System.Drawing.Size(161, 64);
            this.btnBorrow.TabIndex = 46;
            this.btnBorrow.Text = "BORROW";
            this.btnBorrow.UseVisualStyleBackColor = true;
            this.btnBorrow.Click += new System.EventHandler(this.btnBorrow_Click);
            // 
            // txtTransactionNo
            // 
            this.txtTransactionNo.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.txtTransactionNo.Location = new System.Drawing.Point(241, 90);
            this.txtTransactionNo.Name = "txtTransactionNo";
            this.txtTransactionNo.ReadOnly = true;
            this.txtTransactionNo.Size = new System.Drawing.Size(217, 35);
            this.txtTransactionNo.TabIndex = 63;
            this.txtTransactionNo.TabStop = false;
            // 
            // txtBorrowerID
            // 
            this.txtBorrowerID.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBorrowerID.Location = new System.Drawing.Point(191, 153);
            this.txtBorrowerID.Name = "txtBorrowerID";
            this.txtBorrowerID.ReadOnly = true;
            this.txtBorrowerID.Size = new System.Drawing.Size(229, 35);
            this.txtBorrowerID.TabIndex = 64;
            // 
            // txtAccNo
            // 
            this.txtAccNo.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.txtAccNo.Location = new System.Drawing.Point(705, 153);
            this.txtAccNo.Name = "txtAccNo";
            this.txtAccNo.ReadOnly = true;
            this.txtAccNo.Size = new System.Drawing.Size(229, 35);
            this.txtAccNo.TabIndex = 65;
            // 
            // gridBorrowers
            // 
            this.gridBorrowers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridBorrowers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridBorrowers.Location = new System.Drawing.Point(21, 360);
            this.gridBorrowers.Name = "gridBorrowers";
            this.gridBorrowers.RowHeadersWidth = 51;
            this.gridBorrowers.RowTemplate.Height = 24;
            this.gridBorrowers.Size = new System.Drawing.Size(486, 173);
            this.gridBorrowers.TabIndex = 83;
            this.gridBorrowers.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridBorrowers_CellMouseClick);
            // 
            // txtSearchBorrower
            // 
            this.txtSearchBorrower.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchBorrower.Location = new System.Drawing.Point(116, 309);
            this.txtSearchBorrower.Name = "txtSearchBorrower";
            this.txtSearchBorrower.Size = new System.Drawing.Size(229, 35);
            this.txtSearchBorrower.TabIndex = 84;
            this.txtSearchBorrower.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchBorrower_KeyDown);
            // 
            // lblSearchStudent
            // 
            this.lblSearchStudent.AutoSize = true;
            this.lblSearchStudent.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblSearchStudent.Location = new System.Drawing.Point(16, 309);
            this.lblSearchStudent.Name = "lblSearchStudent";
            this.lblSearchStudent.Size = new System.Drawing.Size(94, 29);
            this.lblSearchStudent.TabIndex = 85;
            this.lblSearchStudent.Text = "SEARCH";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstName.Location = new System.Drawing.Point(191, 195);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(229, 35);
            this.txtFirstName.TabIndex = 86;
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastName.Location = new System.Drawing.Point(191, 236);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(229, 35);
            this.txtLastName.TabIndex = 87;
            // 
            // txtTitle
            // 
            this.txtTitle.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.txtTitle.Location = new System.Drawing.Point(703, 195);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(229, 35);
            this.txtTitle.TabIndex = 88;
            // 
            // txtAuthor
            // 
            this.txtAuthor.Font = new System.Drawing.Font("Comic Sans MS", 12F);
            this.txtAuthor.Location = new System.Drawing.Point(703, 236);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.ReadOnly = true;
            this.txtAuthor.Size = new System.Drawing.Size(229, 35);
            this.txtAuthor.TabIndex = 89;
            // 
            // gridBooks
            // 
            this.gridBooks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridBooks.Location = new System.Drawing.Point(577, 360);
            this.gridBooks.Name = "gridBooks";
            this.gridBooks.RowHeadersWidth = 51;
            this.gridBooks.RowTemplate.Height = 24;
            this.gridBooks.Size = new System.Drawing.Size(486, 173);
            this.gridBooks.TabIndex = 90;
            this.gridBooks.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridBooks_CellMouseClick);
            // 
            // lblSearchBook
            // 
            this.lblSearchBook.AutoSize = true;
            this.lblSearchBook.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold);
            this.lblSearchBook.Location = new System.Drawing.Point(577, 311);
            this.lblSearchBook.Name = "lblSearchBook";
            this.lblSearchBook.Size = new System.Drawing.Size(94, 29);
            this.lblSearchBook.TabIndex = 92;
            this.lblSearchBook.Text = "SEARCH";
            // 
            // txtSearchBook
            // 
            this.txtSearchBook.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchBook.Location = new System.Drawing.Point(677, 311);
            this.txtSearchBook.Name = "txtSearchBook";
            this.txtSearchBook.Size = new System.Drawing.Size(229, 35);
            this.txtSearchBook.TabIndex = 91;
            this.txtSearchBook.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchBook_KeyDown);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(864, 561);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(199, 80);
            this.btnAdd.TabIndex = 93;
            this.btnAdd.Text = "BORROW";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // frmTransactionBorrow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 653);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblSearchBook);
            this.Controls.Add(this.txtSearchBook);
            this.Controls.Add(this.gridBooks);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblSearchStudent);
            this.Controls.Add(this.txtSearchBorrower);
            this.Controls.Add(this.gridBorrowers);
            this.Controls.Add(this.txtAccNo);
            this.Controls.Add(this.txtBorrowerID);
            this.Controls.Add(this.txtTransactionNo);
            this.Controls.Add(this.btnBorrow);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.lblAuthorHolder);
            this.Controls.Add(this.lblTitleHolder);
            this.Controls.Add(this.lblAccNum);
            this.Controls.Add(this.lblLast);
            this.Controls.Add(this.lblFirst);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblBorrowerID);
            this.Controls.Add(this.lblTransactionNo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmTransactionBorrow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BORROW FORM";
            this.Load += new System.EventHandler(this.frmTransactionBorrow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridBorrowers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridBooks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblBorrowerID;
        private System.Windows.Forms.Label lblTransactionNo;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Label lblAccNum;
        private System.Windows.Forms.Label lblTitleHolder;
        private System.Windows.Forms.Label lblAuthorHolder;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnBorrow;
        private System.Windows.Forms.TextBox txtTransactionNo;
        private System.Windows.Forms.TextBox txtBorrowerID;
        private System.Windows.Forms.TextBox txtAccNo;
        private System.Windows.Forms.DataGridView gridBorrowers;
        private System.Windows.Forms.TextBox txtSearchBorrower;
        private System.Windows.Forms.Label lblSearchStudent;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.DataGridView gridBooks;
        private System.Windows.Forms.Label lblSearchBook;
        private System.Windows.Forms.TextBox txtSearchBook;
        private System.Windows.Forms.Button btnAdd;
    }
}