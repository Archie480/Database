﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmAdminDashboard : Form
    {
        public frmAdminDashboard()
        {
            InitializeComponent();
        }

        private void bOOKSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBooks frm = new frmBooks();
            frm.Show();
        }

        private void bORROWERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBorrowers frm = new frmBorrowers();
            frm.Show();
        }

        private void frmAdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void bORROWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTransactionBorrow frm = new frmTransactionBorrow();
            frm.Show();
        }

        private void rETURNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTransactionReturn frm = new frmTransactionReturn();
            frm.Show();
        }


        private void bOOKREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void bORROWERREPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tRANSACTIONSToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
