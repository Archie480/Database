﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class frmLogin : Form
    {
        static string conString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\IMDBSYS\MIDTERM\LibrarySystem\LibSysDB.mdf;Integrated Security=True";
        public SqlConnection con = new SqlConnection(conString);
        public SqlCommand cmd;
        public SqlDataReader reader;

        public frmLogin()
        {
            InitializeComponent();
        }

        private void lblSignup_Click(object sender, EventArgs e)
        {
            new frmSignup().Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("SELECT * FROM Accounts WHERE Username LIKE '" + txtUsername.Text + "'", con);
                cmd.ExecuteNonQuery();

                reader = cmd.ExecuteReader();

                string vusername;
                string vpassword;

                reader.Read();


                vusername = reader["Username"].ToString();
                vpassword = reader["Password"].ToString();

                //DECRYPT THE PASSWORD FROM THE DATABASE TO COMPARE IT TO THE PASSWORD TEXTBOX
                string vtemppass = DecryptPassword(vpassword);

                vusername = vusername.ToLower();
                String tempusername = txtUsername.Text.ToLower();

                if (tempusername.Equals(vusername) && txtPassword.Text.Equals(vtemppass))
                {
                    new frmAdminDashboard().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("INCORRECT PASSWORD!");
                    txtPassword.Text = "";
                }


                reader.Close();

                con.Close();
            }
            catch //TO CATCH ERROR WHEN SEARCHING A USER ID THAT DOESNT EXIST IN THE DATABASE
            {
                MessageBox.Show("ACCOUNT DOESN'T EXIST!");
                txtUsername.Text = "";
                txtPassword.Text = "";
            }
        }

        public string DecryptPassword(string encrypted)
        {
            string Key = "ArchieBontogXXXX";

            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(encrypted);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(Key);
                aes.IV = iv;

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
