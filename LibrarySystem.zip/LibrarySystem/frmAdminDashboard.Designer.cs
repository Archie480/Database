﻿namespace LibrarySystem
{
    partial class frmAdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fILEMAINTENANCEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bOOKSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bORROWERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tRANSACTIONSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bORROWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rETURNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bORROWERREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bOOKREPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fILEMAINTENANCEToolStripMenuItem,
            this.tRANSACTIONSToolStripMenuItem,
            this.rEPORTSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1019, 43);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fILEMAINTENANCEToolStripMenuItem
            // 
            this.fILEMAINTENANCEToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.fILEMAINTENANCEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bOOKSToolStripMenuItem,
            this.bORROWERSToolStripMenuItem});
            this.fILEMAINTENANCEToolStripMenuItem.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fILEMAINTENANCEToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.fILEMAINTENANCEToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Silver;
            this.fILEMAINTENANCEToolStripMenuItem.Name = "fILEMAINTENANCEToolStripMenuItem";
            this.fILEMAINTENANCEToolStripMenuItem.Size = new System.Drawing.Size(316, 39);
            this.fILEMAINTENANCEToolStripMenuItem.Text = "FILE MAINTENANCE";
            // 
            // bOOKSToolStripMenuItem
            // 
            this.bOOKSToolStripMenuItem.Name = "bOOKSToolStripMenuItem";
            this.bOOKSToolStripMenuItem.Size = new System.Drawing.Size(294, 40);
            this.bOOKSToolStripMenuItem.Text = "BOOKS";
            this.bOOKSToolStripMenuItem.Click += new System.EventHandler(this.bOOKSToolStripMenuItem_Click);
            // 
            // bORROWERSToolStripMenuItem
            // 
            this.bORROWERSToolStripMenuItem.Name = "bORROWERSToolStripMenuItem";
            this.bORROWERSToolStripMenuItem.Size = new System.Drawing.Size(294, 40);
            this.bORROWERSToolStripMenuItem.Text = "BORROWERS";
            this.bORROWERSToolStripMenuItem.Click += new System.EventHandler(this.bORROWERSToolStripMenuItem_Click);
            // 
            // tRANSACTIONSToolStripMenuItem
            // 
            this.tRANSACTIONSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bORROWToolStripMenuItem,
            this.rETURNToolStripMenuItem});
            this.tRANSACTIONSToolStripMenuItem.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tRANSACTIONSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tRANSACTIONSToolStripMenuItem.Name = "tRANSACTIONSToolStripMenuItem";
            this.tRANSACTIONSToolStripMenuItem.Size = new System.Drawing.Size(263, 39);
            this.tRANSACTIONSToolStripMenuItem.Text = "TRANSACTIONS";
            this.tRANSACTIONSToolStripMenuItem.Click += new System.EventHandler(this.tRANSACTIONSToolStripMenuItem_Click);
            // 
            // bORROWToolStripMenuItem
            // 
            this.bORROWToolStripMenuItem.Name = "bORROWToolStripMenuItem";
            this.bORROWToolStripMenuItem.Size = new System.Drawing.Size(235, 40);
            this.bORROWToolStripMenuItem.Text = "BORROW";
            this.bORROWToolStripMenuItem.Click += new System.EventHandler(this.bORROWToolStripMenuItem_Click);
            // 
            // rETURNToolStripMenuItem
            // 
            this.rETURNToolStripMenuItem.Name = "rETURNToolStripMenuItem";
            this.rETURNToolStripMenuItem.Size = new System.Drawing.Size(235, 40);
            this.rETURNToolStripMenuItem.Text = "RETURN";
            this.rETURNToolStripMenuItem.Click += new System.EventHandler(this.rETURNToolStripMenuItem_Click);
            // 
            // rEPORTSToolStripMenuItem
            // 
            this.rEPORTSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bORROWERREPORTToolStripMenuItem,
            this.bOOKREPORTToolStripMenuItem});
            this.rEPORTSToolStripMenuItem.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rEPORTSToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.rEPORTSToolStripMenuItem.Name = "rEPORTSToolStripMenuItem";
            this.rEPORTSToolStripMenuItem.Size = new System.Drawing.Size(174, 39);
            this.rEPORTSToolStripMenuItem.Text = "REPORTS";
            // 
            // bORROWERREPORTToolStripMenuItem
            // 
            this.bORROWERREPORTToolStripMenuItem.Name = "bORROWERREPORTToolStripMenuItem";
            this.bORROWERREPORTToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.bORROWERREPORTToolStripMenuItem.Text = "BORROWER REPORT";
            this.bORROWERREPORTToolStripMenuItem.Click += new System.EventHandler(this.bORROWERREPORTToolStripMenuItem_Click);
            // 
            // bOOKREPORTToolStripMenuItem
            // 
            this.bOOKREPORTToolStripMenuItem.Name = "bOOKREPORTToolStripMenuItem";
            this.bOOKREPORTToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.bOOKREPORTToolStripMenuItem.Text = "BOOK REPORT";
            this.bOOKREPORTToolStripMenuItem.Click += new System.EventHandler(this.bOOKREPORTToolStripMenuItem_Click);
            // 
            // frmAdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1019, 553);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1037, 600);
            this.MinimumSize = new System.Drawing.Size(1037, 600);
            this.Name = "frmAdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAdminDashboard";
            this.Load += new System.EventHandler(this.frmAdminDashboard_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fILEMAINTENANCEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bOOKSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bORROWERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tRANSACTIONSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rEPORTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bORROWToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rETURNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bORROWERREPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bOOKREPORTToolStripMenuItem;
    }
}